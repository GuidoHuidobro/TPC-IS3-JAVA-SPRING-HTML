$(".close").click(function() {
  $(this)
    .parent(".alert")
    .fadeOut();
});