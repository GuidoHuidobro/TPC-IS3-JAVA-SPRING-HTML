package com.TP.IS3.GRUPO3.repositorys;

import org.springframework.data.jpa.repository.JpaRepository;

import com.TP.IS3.GRUPO3.domain.Docente;

public interface IDocenteRepository extends JpaRepository<Docente, Integer>{

}
