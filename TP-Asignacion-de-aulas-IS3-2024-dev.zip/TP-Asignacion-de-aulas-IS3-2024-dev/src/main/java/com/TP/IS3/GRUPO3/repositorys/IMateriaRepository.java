package com.TP.IS3.GRUPO3.repositorys;

import org.springframework.data.jpa.repository.JpaRepository;

import com.TP.IS3.GRUPO3.domain.Materia;

public interface IMateriaRepository extends JpaRepository<Materia, Integer>{
    
}
